import { Readable } from 'stream';
import busboy from 'busboy';
import fetch from 'node-fetch';

const MAX_FILE_SIZE_BYTES = 1 * 1024 * 1024; // 1MB

export const handler = async (event) => {
  try {
    const method = event.requestContext?.http?.method || event.httpMethod;
    if (method !== 'POST') {
      return _response(405, { error: 'Method Not Allowed' });
    }

    const contentType = event.headers['content-type'] || event.headers['Content-Type'];
    const timestamp = event.queryStringParameters?.timestamp;

    if (!timestamp || !contentType?.includes('multipart/form-data')) {
      return _response(400, { error: 'Missing or invalid timestamp or content type' });
    }

    const bodyBuffer = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf8');
    const bb = busboy({ headers: { 'content-type': contentType } });

    let fileBuffer = Buffer.alloc(0);
    let fileMime = '';
    let fileFound = false;

    const parsePromise = new Promise((resolve, reject) => {
      bb.on('file', (fieldname, file, info) => {
        const { mimeType } = info;
        fileMime = mimeType;
        fileFound = true;

        file.on('data', (data) => {
          fileBuffer = Buffer.concat([fileBuffer, data]);
          if (fileBuffer.length > MAX_FILE_SIZE_BYTES) {
            reject(new Error('Payload Too Large'));
          }
        });
      });

      bb.on('finish', () => {
        resolve();
      });

      bb.on('error', reject);
    });

    Readable.from(bodyBuffer).pipe(bb);
    await parsePromise;

    if (!fileFound || !fileMime.includes('audio/')) {
      return _response(400, { error: 'Missing or invalid audio file' });
    }

    const openaiApiKey = process.env.OPENAI_API_KEY;
    if (!openaiApiKey) {
      return _response(500, { error: 'Missing OpenAI API key' });
    }

    const formData = new FormData();
    formData.append('file', new Blob([fileBuffer], { type: fileMime }), 'audio.webm');
    formData.append('model', 'whisper-1');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${openaiApiKey}`
      },
      body: formData
    });

    const resultText = await response.text();

    if (!response.ok) {
      console.error(`Whisper error ${response.status}: ${resultText}`);
      return _response(response.status, {
        error: 'OpenAI error',
        status: response.status,
        details: resultText
      });
    }

    const result = JSON.parse(resultText);
    return _response(200, {
      timestamp,
      transcription: result.text
    });

  } catch (err) {
    console.error('Unhandled error', err);
    return _response(500, {
      error: 'Internal server error',
      message: err.message,
      stack: err.stack
    });
  }
};

function _response(statusCode, body) {
  return {
    statusCode,
    body: JSON.stringify(body)
  };
}
